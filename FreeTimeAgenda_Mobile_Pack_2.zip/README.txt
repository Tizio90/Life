FreeTimeAgenda - Mobile Edition Package
========================================

CONTENTS
--------
1. FreeTimeAgenda_mobile.html
   Standalone mobile-optimized single-file app (same as embedded in the APK).

2. FreeTimeAgenda-APK/
   Complete Android Studio project, ready to build.

HOW TO BUILD THE APK
--------------------
1. Open Android Studio
2. File > Open > select the FreeTimeAgenda-APK folder
3. Wait for Gradle sync to finish (needs internet on first sync)
4. Build > Build App Bundle(s) / APK(s) > Build APK(s)
5. APK output: app/build/outputs/apk/debug/app-debug.apk
6. Transfer to your phone and install

LOG SCREEN (updated)
--------------------
- Sections are now a compact accordion: tap a section (Journal, Reading,
  Watching...) to unfold its form; the previous one folds away.
- Collapsed rows show colour tag, name, today's count and a chevron.
- The old 'recent' suggestion strips are gone on phones - previous titles
  appear as native type-ahead while you type instead.
- Today snapshot and history filters are single swipeable strips.
- Data is still memory-only: export encrypted backups regularly (green
  header button). Back button minimizes the app without losing data.

package com.freetimeagenda.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader

class MainActivity : Activity() {

    private lateinit var webView: WebView

    /** Bytes of the backup waiting to be written once the user picks a
     *  destination in the system "Save to…" (SAF) dialog. */
    private var pendingSaveBytes: ByteArray? = null

    /** Callback for &lt;input type="file"&gt; — used by "Import backup". */
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    /**
     * Serves files from app/src/main/assets/ over
     * https://appassets.androidplatform.net/assets/...
     *
     * That https origin makes the page a *secure context*, which is what
     * enables window.crypto.subtle — the Web Crypto API the whole
     * encrypted-backup feature (AES-256-GCM export / import) is built on.
     * Loading the same file via file:// would leave crypto.subtle
     * undefined and export/import would silently fail.
     */
    private val assetLoader: WebViewAssetLoader = WebViewAssetLoader.Builder()
        .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
        .build()

    /**
     * Native bridge injected as window.FtaBridge.
     *
     * The page feature-detects it (window.FtaBridge && FtaBridge.saveFile)
     * and uses it as the primary export route: saveFile() opens Android's
     * Storage Access Framework "Save to…" dialog, where any folder on the
     * phone can be chosen (Documents, Downloads, SD card...) and the file
     * name can be edited before saving.
     *
     * The result is reported back asynchronously through
     * window.__ftaSaveResult('ok' | 'cancel' | 'error').
     */
    inner class FtaBridge {

        @JavascriptInterface
        fun isAvailable(): Boolean = true

        @JavascriptInterface
        fun appVersion(): String = "1.5-mobile"

        @JavascriptInterface
        fun saveFile(fileName: String, base64: String) {
            val bytes = try {
                Base64.decode(base64, Base64.DEFAULT)
            } catch (e: IllegalArgumentException) {
                notifySaveResult("error")
                return
            }
            // addJavascriptInterface runs on a background thread — hop to UI.
            runOnUiThread {
                pendingSaveBytes = bytes
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(
                        Intent.EXTRA_TITLE,
                        if (fileName.isNotBlank()) fileName else "freetimeagenda-backup.json"
                    )
                }
                try {
                    startActivityForResult(intent, REQ_SAVE_BACKUP)
                } catch (e: ActivityNotFoundException) {
                    pendingSaveBytes = null
                    notifySaveResult("error")
                }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true          // harmless; app keeps data in RAM
            allowFileAccess = false           // assets come through the asset loader
            allowContentAccess = false
            mediaPlaybackRequiresUserGesture = true
            cacheMode = WebSettings.LOAD_DEFAULT
            textZoom = 100                    // never inflate font scale inside the app
        }
        webView.setBackgroundColor(BG_COLOR)
        webView.addJavascriptInterface(FtaBridge(), "FtaBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val url = request.url
                // Keep app-asset traffic inside the WebView; open anything
                // else (links in markdown notes, fonts CDN is intercepted
                // transparently) in the external browser.
                if (url.host == "appassets.androidplatform.net") return false
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, url))
                    true
                } catch (e: Exception) {
                    true
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                return try {
                    startActivityForResult(params.createIntent(), REQ_PICK_BACKUP)
                    true
                } catch (e: ActivityNotFoundException) {
                    filePathCallback = null
                    false
                }
            }
        }

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState)
        } else {
            webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (requestCode) {
            REQ_SAVE_BACKUP -> {
                val uri: Uri? = if (resultCode == RESULT_OK) data?.data else null
                if (uri == null) {
                    pendingSaveBytes = null
                    notifySaveResult("cancel")
                    return
                }
                val bytes = pendingSaveBytes
                pendingSaveBytes = null
                if (bytes == null) {
                    notifySaveResult("error")
                    return
                }
                val ok = try {
                    contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(bytes)
                        out.flush()
                        true
                    } ?: false
                } catch (e: Exception) {
                    false
                }
                notifySaveResult(if (ok) "ok" else "error")
            }

            REQ_PICK_BACKUP -> {
                val callback = filePathCallback
                filePathCallback = null
                callback?.onReceiveValue(
                    WebChromeClient.FileChooserParams.parseResult(resultCode, data)
                )
            }

            else -> super.onActivityResult(requestCode, resultCode, data)
        }
    }

    private fun notifySaveResult(status: String) {
        runOnUiThread {
            webView.evaluateJavascript(
                "if (window.__ftaSaveResult) { window.__ftaSaveResult('$status'); }",
                null
            )
        }
    }

    /** Back button parks the app instead of closing it, so the in-memory
     *  data survives while the process is cached in the background. The
     *  process (and the data) dies only when Android evicts it or the
     *  user swipes the app away from Recents — export before that. */
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        moveTaskToBack(true)
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    companion object {
        private const val REQ_SAVE_BACKUP = 4001
        private const val REQ_PICK_BACKUP = 4002
        private const val BG_COLOR = -11053283 // #14171D (app dark background)
    }
}

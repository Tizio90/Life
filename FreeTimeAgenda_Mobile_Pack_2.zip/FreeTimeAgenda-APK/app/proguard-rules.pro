# Keep the JS bridge methods that the page calls via window.FtaBridge.
# (Release builds currently have minifyEnabled false, but this keeps the
# bridge safe if it is ever enabled.)
-keepclassmembers class com.freetimeagenda.app.MainActivity$FtaBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

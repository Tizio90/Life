# FreeTimeAgenda — Android APK project

A minimal, privacy-friendly WebView wrapper around **FreeTimeAgenda (mobile)**.
No analytics, no tracking, no storage of your data — the app keeps entries in
RAM only, exactly like the original, and you persist them by exporting the
encrypted JSON backup **into any folder you choose** on the phone.

```
Project layout
├── settings.gradle / build.gradle / gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/freetimeagenda/app/MainActivity.kt
        ├── assets/index.html          ← the mobile app (this is the whole UI)
        └── res/…                      ← theme, colours, launcher icons
```

---

## 1. Build the APK

**With Android Studio (easiest)**

1. Open Android Studio → **File ▸ Open…** → select this `FreeTimeAgenda-APK` folder.
2. Let Gradle sync (first sync downloads dependencies, needs internet).
3. **Build ▸ Build App Bundle(s) / APK(s) ▸ Build APK(s).**
4. The APK appears at `app/build/outputs/apk/debug/app-debug.apk`.
   Copy it to your phone and install it ("Install unknown apps" permission
   may be asked the first time).

**From the command line** (Android Studio installed, `gradle` on PATH):

```bash
cd FreeTimeAgenda-APK
gradle wrapper          # one-time: generates ./gradlew from the wrapper properties
./gradlew assembleDebug
# → app/build/outputs/apk/debug/app-debug.apk
```

**Release build** (smaller, no debug overhead): create a signing config in
`app/build.gradle` or use **Build ▸ Generate Signed Bundle / APK** in Android
Studio, then run `./gradlew assembleRelease`.

---

## 2. How "Export to a folder of my choosing" works

1. Tap the **green download button** in the header (quick export) — or
   ⚙ menu ▸ *Export backup*.
2. Set/enter the encryption password as usual (min 8 chars).
3. The **Android system "Save to…" dialog** opens (Storage Access Framework):
   - navigate to **any folder** — Documents, Downloads, SD card, cloud folders…
   - the file name `freetimeagenda-backup-YYYY-MM-DD.json` is pre-filled and **editable**.
4. Tap **Save**. Done — the encrypted JSON lands exactly where you picked it.

Under the hood the page calls `window.FtaBridge.saveFile(name, base64)` —
a tiny JavaScript↔Kotlin bridge in `MainActivity.kt` that writes the bytes
through `ACTION_CREATE_DOCUMENT`. If the bridge is ever unavailable (e.g. you
open `index.html` in a normal browser), the app transparently falls back to
`showSaveFilePicker` → share sheet → normal download.

**Import** (⚙ menu ▸ *Import backup*) opens Android's file picker at any
location, including the folder you exported to.

---

## 3. Important: data lifecycle (read this!)

The app is **memory-only by design** — same as the desktop version:

- **Back button / Home** → the app is parked in the background and the data
  stays alive while the process is cached. Returning to the app restores it.
- **Swipe away from Recents / Android kills the process / reboot** → data is
  gone unless you exported a backup. Export regularly; import the latest JSON
  when the app starts empty.
- If you enable Developer-options ▸ "Don't keep activities", the data dies on
  every backgrounding. Leave that off.

Rotation, keyboard, theme changes are handled in-manifest
(`configChanges`) so the WebView is **never reloaded** mid-session —
that is what would otherwise wipe the in-memory data.

---

## 4. Updating the app inside the APK

The UI is a single file: `app/src/main/assets/index.html`.

When you edit `FreeTimeAgenda_mobile.html` elsewhere, copy it over
`app/src/main/assets/index.html` and rebuild:

```bash
cp FreeTimeAgenda_mobile.html FreeTimeAgenda-APK/app/src/main/assets/index.html
```

## 5. Customisation

| What | Where |
|---|---|
| App name | `app/src/main/res/values/strings.xml` (`app_name`) |
| App ID / package | `applicationId` in `app/build.gradle` (and `namespace`) |
| Version | `versionCode` / `versionName` in `app/build.gradle` |
| Status-bar colour | `res/values/colors.xml` → `fta_bg` |
| Launcher icon | `res/drawable/ic_launcher_foreground.xml` + `res/mipmap-*/ic_launcher.png` |

## 6. Notes

- **Fonts**: the HTML loads Google Fonts when online. Offline the app falls
  back to system serif/mono fonts — everything still works. Delete the
  `INTERNET` permission from the manifest if you want a strictly zero-network
  build.
- **Secure context**: the app is served via `WebViewAssetLoader`
  (`https://appassets.androidplatform.net`), a real https origin — this is
  what enables Web Crypto (`crypto.subtle`) for the AES-256-GCM backup
  encryption. Wrappers that load `file:///android_asset/...` break encryption;
  this project deliberately does not.
- **minSdk 24** = Android 7.0+, **targetSdk 34** = Android 14.

FreeTimeAgenda - Mobile Edition Package
========================================

CONTENTS
--------
1. FreeTimeAgenda_mobile.html
   Standalone mobile-optimized single-file app (same as the one embedded in the APK).
   Open directly in any mobile browser, or host it anywhere.

2. FreeTimeAgenda-APK/
   Complete Android Studio project, ready to build.

HOW TO BUILD THE APK
--------------------
1. Open Android Studio
2. File > Open > select the FreeTimeAgenda-APK folder
3. Wait for Gradle sync to finish (needs internet on first sync)
4. Build > Build App Bundle(s) / APK(s) > Build APK(s)
5. APK output: app/build/outputs/apk/debug/app-debug.apk
6. Transfer to your phone and install (enable "Install unknown apps" if prompted)

REQUIREMENTS
------------
- Android Studio (Hedgehog or newer recommended)
- JDK 17 (bundled with recent Android Studio)
- Android SDK 34

KEY FEATURES
------------
- Pure in-memory data storage (faithful port of the desktop original - data lives
  only while the app is running; export encrypted archives to keep them safe)
- AES-256-GCM encrypted export/import via Web Crypto
- Native folder/file picker (SAF) - save encrypted backups to ANY folder on the phone
- Quick-export button in the header
- Bottom tab bar navigation (Log / Dashboard / Notes)
- Back button minimizes the app instead of killing it (keeps in-memory data alive)

IMPORTANT - DATA LIFECYCLE
--------------------------
Data is intentionally NOT persisted (faithful to the desktop version).
When the app process is killed by Android, data is gone.
Export an encrypted archive regularly - that is what the green header button is for.
